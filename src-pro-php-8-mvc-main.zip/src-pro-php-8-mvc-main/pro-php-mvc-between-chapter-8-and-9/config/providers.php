<?php

return [
    \Framework\Provider\ValidationProvider::class,
    \Framework\Provider\ViewProvider::class,
];
