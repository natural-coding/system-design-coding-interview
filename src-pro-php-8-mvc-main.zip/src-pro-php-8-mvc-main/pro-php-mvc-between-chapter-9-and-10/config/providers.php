<?php

return [
    \Framework\Provider\DatabaseProvider::class,
    \Framework\Provider\ResponseProvider::class,
    \Framework\Provider\ValidationProvider::class,
    \Framework\Provider\ViewProvider::class,
];
