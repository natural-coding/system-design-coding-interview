<?php $this->extends('layouts/products'); ?>
<h1>Product</h1>
<?php $this->includes('includes/product-details', ['name' => $product]); ?>
