<!doctype html>
<html lang="en">
    <head>
        <title>Whoosh!</title>
        <link rel="stylesheet" href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" />
        <meta charset="utf-8" />
    </head>
    <body>
        <div class="container mx-auto font-sans">
            <h1 class="text-xl font-semibold">Welcome to Whoosh!</h1>
            <p>Here, you can buy {number} rockets.</p>
        </div>
    </body>
</html>
