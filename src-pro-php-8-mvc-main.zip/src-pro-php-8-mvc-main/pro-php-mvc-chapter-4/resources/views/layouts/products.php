<!doctype html>
<html lang="en">
    <head>
        <title>Whoosh! Products</title>
        <link rel="stylesheet" href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" />
        <meta charset="utf-8" />
    </head>
    <body>
        <div class="container mx-auto font-sans">
            <?php print $contents; ?>
        </div>
    </body>
</html>
