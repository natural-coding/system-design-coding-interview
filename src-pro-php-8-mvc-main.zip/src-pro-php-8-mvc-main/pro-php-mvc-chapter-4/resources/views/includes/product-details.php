<p>
    This is the product page for <?php print $this->escape($name); ?>.
</p>
