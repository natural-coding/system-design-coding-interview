# Whoosh website

To run the local development server, try:

```
export PHP_ENV=prod && php -S 127.0.0.1:8000 -t .
```

To make requests with cURL, try:

```
curl -X DELETE http://127.0.0.1:8000/old-home
```
