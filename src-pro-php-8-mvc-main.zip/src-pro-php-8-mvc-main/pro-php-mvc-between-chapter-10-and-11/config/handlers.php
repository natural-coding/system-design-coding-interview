<?php

return [
    'exceptions' => \App\Exceptions\Handler::class,
];
