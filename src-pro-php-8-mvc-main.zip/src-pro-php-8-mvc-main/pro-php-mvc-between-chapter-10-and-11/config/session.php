<?php

return [
    'default' => 'native',
    'native' => [
        'type' => 'native',
        'prefix' => 'framework_',
    ],
];
