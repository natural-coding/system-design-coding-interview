<?php

namespace Framework\Routing\Exception;

use RuntimeException;

class RouteException extends RuntimeException
{
}
