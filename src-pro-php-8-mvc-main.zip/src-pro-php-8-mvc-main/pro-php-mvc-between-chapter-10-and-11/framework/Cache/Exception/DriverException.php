<?php

namespace Framework\Cache\Exception;

use RuntimeException;

class DriverException extends RuntimeException
{
}
