<?php

namespace Framework\Session\Exception;

use RuntimeException;

class DriverException extends RuntimeException
{
}
