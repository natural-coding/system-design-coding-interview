<?php

namespace Framework\Database\Exception;

use PDOException;

class ConnectionException extends PDOException
{
}
