<?php

namespace Framework\Database\Exception;

use PDOException;

class MigrationException extends PDOException
{
}
