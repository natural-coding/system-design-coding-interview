<?php

namespace Framework\Filesystem\Exception;

use RuntimeException;

class DriverException extends RuntimeException
{
}
