<?php

use Framework\Database\Command\MigrateCommand;
use Framework\Support\Command\ServeCommand;

return [
    MigrateCommand::class,
    ServeCommand::class,
];
